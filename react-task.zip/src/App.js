
import './App.css';
import HomePage from './pages/Home/HomePage';

function App() {
  return (
    <div className="App">
    <HomePage />
    </div>
  );
}

export default App;
